<div class="modificaprodotto">
  

	<h1>Descrizione</h1>

   

	<p style="text-align: left; font-size: 15px; margin-left: 4px;">
		Il progetto consiste in un sito di acquisto on-line di vestiti con consegna a domicilio.<br>Una volta entrati è possibile scegliere la categoria di vestiti dalla quale noi vorremo acquistare il prodotto, e successivamente potremmo vedere tutti i prodotti collegati alla categoria da noi selezionata.<br>Nel carrello avremo la possibilita di vedere i prodotti da noi selezionati, e il costo totale dell' ordine.<br>Per ultimare l'operazione di acquisto sarà necessario connettersi al proprio account, e se non provvisti dello stesso, ne dovremo creare uno.Nella lista degli ordini è presente l'archivio degli ordini da noi effettuati.<br>Infine è anche presente un account amministratore che oltre a poter fare le cose che fanno anche gli altri account, ha accesso a un pannello amministrativo dal quale è possibile aggiungere ,modificare o eliminare i relativi prodotti.
        
	</p>
	
</div>