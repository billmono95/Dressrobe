
<div id="home2" onmouseover ="begin();">

<form action="php/home2proc.php" method="POST">
		<a href="index.php?p=home2"><label id="changespacing" > <p>Welcome in
			Dressrobe </p> <br></a>

		
		
		</label>
		<input type="submit" id="entra" class="tasti" name="invia" value="Entra">
	</form>



</div>