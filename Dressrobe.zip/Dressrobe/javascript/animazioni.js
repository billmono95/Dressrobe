var clock;

var i = 26;
var j = 22;
function mostra_carrello(){
	
	
	document.getElementById("preview_acquisti").style.visibility = "visible"
    
}

function chiama(){

document.getElementById("preview_acquisti").style.visibility = "hidden"




}




function size(){
document.getElementsByTagName("input")[0].style.backgroundColor = "green"

   


}


function changetext(){





document.getElementById("changespacing").style.letterSpacing = i+"px";

i--;

if (i <= 6){

i = 6;
clearInterval(clock);
}

}





function begin(){


clock = setInterval("changetext()",140);


}

function changetextlogin(){





document.getElementById("loginspacing").style.letterSpacing = j+"px";

j--;

if (j <= 6){

j = 6;
clearInterval(clock);
}

}


function beginlogin(){


clock = setInterval("changetextlogin()",120);


}

function changetextsignin(){





document.getElementById("signinspacing").style.letterSpacing = i+"px";

i--;

if (i <= 6){

i = 6;
clearInterval(clock);
}

}


function beginsignin(){


clock = setInterval("changetextsignin()",120);


}


function ordine(){


	alert("L'ordine è stato effettuato con successo");
	return;
}


function changeordine(){





document.getElementById("ordinespacing").style.letterSpacing = i+"px";

i--;

if (i <= 6){

i = 6;
clearInterval(clock);
}

}


function beginordine(){


clock = setInterval("changeordine()",120);


}

function mostra() {
	if(document.getElementById('successo').style.visibility=='hidden')
		document.getElementById('loginform').style.visibility='visible';
	
}
