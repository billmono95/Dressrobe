function validate(){

var name = document.getElementById("username");

var pass = document.getElementById("password");

if (name.value=="" ){

	name.style.borderColor = "red";
	var err=document.getElementById("errore");
    err.innerHTML="Inserire username";
    err.style.color="red";
    return false;
}

if (name.value!=""){

	name.style.borderColor = "#878787";
   
	
}if (pass.value=="" ){

	pass.style.borderColor = "red";
	var err2=document.getElementById("errore");
    err2.innerHTML="Inserire password";
    err2.style.color="red";
    return false;
}

if (pass.value!=""){

	pass.style.borderColor = "#878787";
    
	
}return true;

    }


function register(){


	

var nom = document.getElementById('nome');
var cognom = document.getElementById('cognome');
var emai = document.getElementById('email');
var utent = document.getElementById('utente');
var telefon = document.getElementById('telefono');
var indirizz = document.getElementById('indirizzo');
var civic = document.getElementById('civico');
var passwor = document.getElementById('pass');
var confermapass = document.getElementById('confermapassword');


if (nom.value=="" ){

	nom.style.borderColor = "red";
	
}

if (nom.value!=""){

	nom.style.borderColor = "#878787";
   
	
}if (cognom.value=="" ){
cognom.style.borderColor = "red";

}

if (cognom.value!=""){

	cognom.style.borderColor = "#878787";
    
}if (emai.value=="" ){

	emai.style.borderColor = "red";
	
}

if (emai.value!=""){

	emai.style.borderColor = "#878787";
   
	
}if (utent.value=="" ){
utent.style.borderColor = "red";

}

if (utent.value!=""){

	utent.style.borderColor = "#878787";
    
}


if (telefon.value=="" ){

	telefon.style.borderColor = "red";
	
}

if (telefon.value!=""){

	telefon.style.borderColor = "#878787";
   
	
}if (indirizz.value=="" ){
indirizz.style.borderColor = "red";

}

if (indirizz.value!=""){

	indirizz.style.borderColor = "#878787";
    
}if (civic.value=="" ){

	civic.style.borderColor = "red";
	
}

if (civic.value!=""){

	civic.style.borderColor = "#878787";
   
	
}


if (passwor.value=="" ){

	passwor.style.borderColor = "red";
	
}

if (passwor.value!=""){

	passwor.style.borderColor = "#878787";
   
	
}

if (confermapass.value=="" ){
confermapass.style.borderColor = "red";

}

if (confermapass.value!=""){

	confermapass.style.borderColor = "#878787";
    
}

if( nom.value=="" || cognom.value=="" || emai.value=="" || utent.value=="" || telefon.value=="" || indirizz.value=="" || civic.value=="" 
	||  passwor.value=="" || confermapass.value=="" ){

	var err=document.getElementById("error");
    err.innerHTML="Inserire tutti i dati ";
    err.style.color="red";
    return false;
    
}

if(passwor.value != confermapass.value){


	var err=document.getElementById("error");
    err.innerHTML="Le due password non coincidono";
    err.style.color="red";
    return false;

}


return true;
	

    }




function modificadati(){


var newpass = document.getElementById('newpass');
var confermapass = document.getElementById('conferpassword');


if(newpass.value != confermapass.value){


	var err=document.getElementById("error");
    err.innerHTML="Le due password non coincidono";
    err.style.color="red";
    return false;

}



}















